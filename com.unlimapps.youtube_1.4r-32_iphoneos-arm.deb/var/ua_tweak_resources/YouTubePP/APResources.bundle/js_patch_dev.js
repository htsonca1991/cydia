require('NSMutableDictionary,NSNumber,NSPropertyListSerialization,UAToolsHelper,UIDevice,NSString');
if (!UAToolsHelper.respondsToSelector("properATSDataFromData:") && UIDevice.currentDevice().systemVersion().compare_options(NSString.stringWithString('10.0'), 64) != -1) {
  defineClass('__NSCFURLSessionConfiguration', {
      __atsContext: function() {
          var states = NSMutableDictionary.new();
          states.setObject_forKey(NSNumber.numberWithBool(true),"NSAllowsArbitraryLoads");
          return NSPropertyListSerialization.dataWithPropertyList_format_options_error(states, 100, 0, null);
      },
  });
  defineClass('NSURLSessionConfiguration', {
      __atsContext: function() {
          var states = NSMutableDictionary.new();
          states.setObject_forKey(NSNumber.numberWithBool(true),"NSAllowsArbitraryLoads");
          return NSPropertyListSerialization.dataWithPropertyList_format_options_error(states, 100, 0, null);
      },
  });
}
